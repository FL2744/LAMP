<div align="left">

# LAMP

Technical paper: [PDF](main.pdf) · [LaTeX](main.tex) · [Markdown](TECHNICAL_PAPER.md) · [Source bundle](Source.zip)

LAMP: Latent Associative Memory Programming in a Frozen Toy Transformer

William Taggart, Modern and Classical Languages and Literatures, Virginia Tech.

Original project: [GitHub](https://github.com/FL2744/LAMP).

Build with `tectonic main.tex`, or use a LaTeX installation with the `acmart` class and BibTeX. Figure assets and bibliography files are included.

</div>
